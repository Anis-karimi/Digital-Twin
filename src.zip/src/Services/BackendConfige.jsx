export const BACKEND_URL = "http://172.20.13.39:8506";
export const DGTW_URL = "https://dgtw.um.ac.ir";